import cls from './TextArea.module.scss'

const TextArea = () => {
    return (
        <textarea className={cls.area} cols={3}>
            
        </textarea>
    );
}

export default TextArea;
