const settings = {
    meta: {
        url: "https://getter.uz/",
        title: "Getter - Центр информационных технологий и инновационных идей",
        description: "",
        social: {
            graphic: "https://bright-uzbekistan.vercel.app/Images/BrightUzbekistan.png",
            twitter: "@brightuzb",
        },
        type: "website",
        keywords: "Bright Uzbekistan, ozbekiston yangiliklari, yangiliklar, tezkor yangiliklar",
    },
};

export default settings;