export const portfolio = [
    {
        id: 0,
        title: 'Inbound ',
        desc: 'LLC Getter',
        image: '/portfolio/1.png'
    },
    {
        id: 1,
        title: 'Simple Tok',
        desc: 'LLC Getter',
        image: '/portfolio/2.png'
    },
    {
        id: 2,
        title: 'Kassa nazorati',
        desc: 'LLC Getter',
        image: '/portfolio/3.png'
    },
    {
        id: 3,
        title: 'Nayuta',
        desc: 'LLC Getter',
        image: '/portfolio/4.png'
    },
    {
        id: 4,
        title: 'Mebel',
        desc: 'LLC Getter',
        image: '/portfolio/5.png'
    },
    {
        id: 5,
        title: 'Student Hunter',
        desc: 'LLC Getter',
        image: '/portfolio/6.png'
    },
    {
        id: 6,
        title: 'Uz Kassa',
        desc: 'LLC Getter',
        image: '/portfolio/7.png'
    },
    {
        id: 7,
        title: 'Sakura',
        desc: 'LLC Getter',
        image: '/portfolio/8.png'
    },
    {
        id: 8,
        title: 'Makler',
        desc: 'LLC Getter',
        image: '/portfolio/9.png'
    },
    {
        id: 9,
        title: 'Pixer',
        desc: 'LLC Getter',
        image: '/portfolio/10.png'
    },
]