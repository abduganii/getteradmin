export const categories = [
    {
        id: 0,
        hashtag: '#Ux'
    },
    {
        id: 1,
        hashtag: '#Ui'
    },
    {
        id: 2,
        hashtag: '#Uxlaw'
    },
    {
        id: 3,
        hashtag: '#Tutorial'
    },
]