import React from 'react';

const PortfolioPage = () => {
    return (
        <div>
            
        </div>
    );
}

export default PortfolioPage;
