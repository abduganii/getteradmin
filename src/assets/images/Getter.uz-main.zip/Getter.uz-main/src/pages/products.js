import React from 'react';

const ProductsPage = () => {
    return (
        <div>
            
        </div>
    );
}

export default ProductsPage;
